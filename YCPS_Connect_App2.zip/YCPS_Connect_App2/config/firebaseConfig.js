import { initializeApp } from 'firebase/app';
import { initializeAuth, getReactNativePersistence } from 'firebase/auth';
import { getDatabase } from 'firebase/database';
import { getFirestore } from 'firebase/firestore';
import AsyncStorage from '@react-native-async-storage/async-storage';

const firebaseConfig = {
  apiKey: 'AIzaSyB9GwYufV1zIxpuBQ2A_coiOlbjxyWgCc0',
  databaseURL: 'https://ycps-connect-default-rtdb.firebaseio.com/',
  projectId: 'ycps-connect',
  projectNumber: '941815778325',
};

const app = initializeApp(firebaseConfig);

const auth = initializeAuth(app, {
  persistence: getReactNativePersistence(AsyncStorage),
});
const database = getDatabase(app);
const firestore = getFirestore(app);

export { auth, database, firestore };