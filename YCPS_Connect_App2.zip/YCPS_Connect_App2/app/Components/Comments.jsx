import { FlatList, StyleSheet, Text, View } from 'react-native';

function Comments({ route }) {
  const { eventId, comments } = route.params;

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Comments for Event</Text>
      <FlatList
        data={comments}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => (
          <View style={styles.comment}>
            <Text>{item.text}</Text>
            <Text style={styles.commentDate}>
              {new Date(item.createdAt).toLocaleDateString()}
            </Text>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#F5F5F5' },
  header: { fontSize: 20, fontWeight: 'bold', marginBottom: 16 },
  comment: { padding: 10, backgroundColor: '#FFFFFF', marginBottom: 8, borderRadius: 8 },
  commentDate: { fontSize: 12, color: '#6B7280' },
});

export default Comments;