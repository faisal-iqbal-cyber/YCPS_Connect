
import { getApp, getApps, initializeApp } from 'firebase/app';
import { getStorage } from 'firebase/storage';

// Firebase configuration with minimal setup
const firebaseConfig = {
  apiKey: "AIzaSyB9GwYufV1zIxpuBQ2A_coiOlbjxyWgCc0",
  storageBucket: "ycps-connect-default-rtdb.appspot.com",
};

// Initialize Firebase app only if it hasn't been initialized
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
const storage = getStorage(app);

export { app, storage };

