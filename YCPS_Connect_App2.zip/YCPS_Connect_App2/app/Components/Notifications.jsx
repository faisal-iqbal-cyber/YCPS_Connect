import { getDatabase, onValue, ref, update } from 'firebase/database';
import { useEffect, useState } from 'react';
import { FlatList, Image, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

function Notifications({ navigation, route }) {
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const userUID = route.params?.userUID;

  useEffect(() => {
    if (!userUID) {
      setNotifications([]);
      setLoading(false);
      return;
    }

    const db = getDatabase();
    const notificationsRef = ref(db, `notifications/${userUID}`);
    const unsubscribe = onValue(notificationsRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        const notificationsList = Object.values(data).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        setNotifications(notificationsList);
      } else {
        setNotifications([]);
      }
      setLoading(false);
    }, (err) => {
      console.error('Error fetching notifications:', err.message);
      setNotifications([]);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [userUID]);

  const markAsRead = async (notificationId) => {
    const db = getDatabase();
    const notificationRef = ref(db, `notifications/${userUID}/${notificationId}`);
    try {
      await update(notificationRef, { read: true });
      setNotifications((prev) =>
        prev.map((notif) =>
          notif.id === notificationId ? { ...notif, read: true } : notif
        )
      );
    } catch (err) {
      console.error('Error marking notification as read:', err.message);
    }
  };

  const renderNotification = ({ item }) => (
    <View style={[styles.notificationCard, item.read && styles.readNotification]}>
      <Image
        source={{ uri: item.eventImage || 'https://via.placeholder.com/50' }}
        style={styles.notificationImage}
        resizeMode="cover"
      />
      <View style={styles.notificationDetails}>
        <Text style={styles.notificationMessage}>{item.message}</Text>
        <Text style={styles.notificationEvent}>
          Event: {item.eventDescription}
        </Text>
        <Text style={styles.notificationTime}>
          {new Date(item.createdAt).toLocaleString()}
        </Text>
      </View>
      {!item.read && (
        <TouchableOpacity
          style={styles.markReadButton}
          onPress={() => markAsRead(item.id)}
        >
          <Icon name="check" size={20} color="#1E3A8A" />
          <Text style={styles.markReadText}>Mark as Read</Text>
        </TouchableOpacity>
      )}
    </View>
  );

  return (
    <View style={styles.container}>
      <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
        <Text style={styles.backButtonText}>Back</Text>
      </TouchableOpacity>
      <Text style={styles.header}>Notifications</Text>
      {loading ? (
        <ActivityIndicator size="large" color="#1E3A8A" />
      ) : notifications.length === 0 ? (
        <Text style={styles.noNotifications}>No notifications available.</Text>
      ) : (
        <FlatList
          data={notifications}
          keyExtractor={(item) => item.id}
          renderItem={renderNotification}
          contentContainerStyle={styles.notificationList}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#F5F5F5',
  },
  backButton: {
    padding: 8,
    marginBottom: 8,
  },
  backButtonText: {
    fontSize: 16,
    color: '#1E3A8A',
    fontWeight: '600',
  },
  header: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 16,
    textAlign: 'center',
  },
  notificationList: {
    paddingBottom: 20,
  },
  notificationCard: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    padding: 12,
    borderRadius: 8,
    marginBottom: 8,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    shadowOffset: { width: 0, height: 2 },
    elevation: 3,
  },
  readNotification: {
    backgroundColor: '#F0F0F0',
  },
  notificationImage: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 12,
  },
  notificationDetails: {
    flex: 1,
  },
  notificationMessage: {
    fontSize: 16,
    color: '#1F2937',
    fontWeight: '600',
  },
  notificationEvent: {
    fontSize: 14,
    color: '#6B7280',
    marginTop: 4,
  },
  notificationTime: {
    fontSize: 12,
    color: '#6B7280',
    marginTop: 4,
  },
  markReadButton: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 6,
    backgroundColor: '#E0E7FF',
    borderRadius: 8,
  },
  markReadText: {
    fontSize: 14,
    color: '#1E3A8A',
    marginLeft: 4,
  },
  noNotifications: {
    fontSize: 16,
    color: '#6B7280',
    textAlign: 'center',
    marginTop: 20,
  },
});

export default Notifications;