import { useState } from 'react';
import {
  Alert,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';

const StudentLoginScreen = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  async function handleLogin() {
    if (!email || !password) {
      setError('Please enter all the required fields.');
      return;
    }

    try {
      const response = await fetch(
        'https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyB9GwYufV1zIxpuBQ2A_coiOlbjxyWgCc0',
        {
          method: 'POST',
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            email,
            password,
            returnSecureToken: true,
          }),
        }
      );

      const result = await response.json();

      if (result.error) {
        setError(result.error.message || 'Login failed.');
        return;
      }

      const userUID = result.localId;

      const userDataResponse = await fetch(
        `https://ycps-connect-default-rtdb.firebaseio.com/users/${userUID}.json`
      );

      const userData = await userDataResponse.json();

      if (!userData) {
        setError('User profile not found in the database.');
        return;
      }

      if (userData.role !== 'Student') {
        setError('Access denied. This login is for students only.');
        return;
      }

      setError('');

      Alert.alert(
        'Login Successful',
        'You have successfully logged in as a student.',
        [
          {
            text: 'OK',
            onPress: () => navigation.replace('StudentDashboard', { userUID }),
          },
        ],
        { cancelable: false }
      );
    } catch (err) {
      console.error(err);
      setError('Something went wrong. Please try again.');
    }
  }
  const handleBack = () => {
    navigation.navigate('WelcomeScreen');
  };

  return (
    <View style={styles.container}>
      <View style={styles.headerContainer}>
        <Text style={styles.header}>YCPS Connect</Text>
        <Text style={styles.subheader}>Student Login</Text>
      </View>

      <TextInput
        style={styles.input}
        placeholder="Email"
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
        autoCapitalize="none"
        placeholderTextColor="#666"
      />
      <TextInput
        style={styles.input}
        placeholder="Password"
        value={password}
        maxLength={8}
        onChangeText={setPassword}
        secureTextEntry
        placeholderTextColor="#666"
      />

      {error ? <Text style={styles.error}>{error}</Text> : null}

      <TouchableOpacity style={styles.loginButton} onPress={handleLogin}>
        <Text style={styles.buttonText}>Log In</Text>
      </TouchableOpacity>
       <TouchableOpacity style={styles.backButton} onPress={handleBack}>
              <Text style={styles.backButtonText}>Back</Text>
        </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
    padding: 16,
    justifyContent: 'center',
  },
  headerContainer: {
    marginBottom: 24,
  },
  header: {
    fontSize: 36,
    fontWeight: '800',
    color: '#1E3A8A',
    textAlign: 'center',
    letterSpacing: 1.5,
    textShadowColor: 'rgba(0, 0, 0, 0.2)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },
  subheader: {
    fontSize: 20,
    fontWeight: '600',
    color: '#3B82F6',
    textAlign: 'center',
    marginTop: 8,
    textShadowColor: 'rgba(0, 0, 0, 0.1)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 1,
  },
  input: {
    backgroundColor: '#FFFFFF',
    padding: 12,
    borderRadius: 8,
    marginBottom: 16,
    fontSize: 16,
    borderColor: '#DDD',
    borderWidth: 1,
  },
  error: {
    color: '#D32F2F',
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 16,
  },
  loginButton: {
    backgroundColor: '#1E3A8A',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 16,
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  backButton: {
    backgroundColor: '#FFFFFF',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    borderColor: '#1E3A8A',
    borderWidth: 1,
    marginBottom: 16,
  },
  backButtonText: {
    color: '#1E3A8A',
    fontSize: 16,
    fontWeight: '600',
  }
});

export default StudentLoginScreen;