import { createDrawerNavigator } from '@react-navigation/drawer';
import Logout from './Logout';
import StudentHome from './StudentHome';
const Drawer = createDrawerNavigator();

function StudentDashboard({navigation,route}) {
  return (
    <Drawer.Navigator>
      <Drawer.Screen name="StudentHome" component={StudentHome} options={{ title: 'Student Home' }} initialParams={{ userUID: route.params?.userUID }} />
       <Drawer.Screen name="Logout" component={Logout} options={{ title: 'Logout' }} />
    </Drawer.Navigator>
  );
}

export default StudentDashboard;