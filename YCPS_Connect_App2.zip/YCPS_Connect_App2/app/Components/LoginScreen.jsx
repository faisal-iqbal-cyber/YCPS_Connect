import { signInWithEmailAndPassword } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import React, { useState } from 'react';
import {
  Alert,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { auth, firestore } from '../../config/firebaseConfig';

const LoginScreen = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = async () => {
    if (!email || !password) {
      setError('Please fill in all fields');
      return;
    }

    try {
      // Authenticate user with Firebase Authentication
      const userCredential = await signInWithEmailAndPassword(auth, email.trim(), password);
      const user = userCredential.user;

      // Fetch user data from Firestore
      const userDoc = doc(firestore, 'users', user.uid);
      const docSnap = await getDoc(userDoc);

      if (docSnap.exists()) {
        const userData = docSnap.data();
        const role = userData.role ? userData.role.trim().toLowerCase() : 'unknown';

        console.log('Raw role from Firestore:', userData.role); // Debug log: raw role value
        console.log('Processed role:', role); // Debug log: processed role

        // Check role and navigate accordingly
        if (role === 'student') {
          console.log('Navigating to StudentHome');
          navigation.navigate('StudentHome'); // Adjust to your actual student screen name
        } else if (role === 'organizer') {
          console.log('Navigating to OrganizerHome');
          navigation.navigate('OrganizerHome'); // Adjust to your actual organizer screen name
        } else if (role === 'admin') {
          console.log('Navigating to AdminHome');
          navigation.navigate('AdminDashboard'); // Navigate to AdminHome
        } else {
          setError(`Invalid user role: '${role}'. Contact support.`);
          await auth.signOut();
          console.log('Role check failed, signed out');
        }
      } else {
        setError('User data not found in Firestore. Please contact support.');
        await auth.signOut();
        console.log('User data not found, signed out');
      }
    } catch (error) {
      const errorMessage = error.code === 'auth/wrong-password'
        ? 'Incorrect password. Please try again.'
        : error.code === 'auth/user-not-found'
        ? 'No user found with this email.'
        : error.message;
      setError(errorMessage);
      Alert.alert('Login Failed', errorMessage);
      console.log('Login error:', errorMessage);
    }
  };
  const handleBack = () => {
    navigation.navigate('WelcomeScreen');
  };

  return (
    <View style={styles.container}>
      <View style={styles.headerContainer}>
          <Text style={styles.header}>YCPS Connect</Text>
          <Text style={styles.subheader}>Admin Login</Text>
      </View>
      <TextInput
        style={styles.input}
        placeholder="Email"
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
        autoCapitalize="none"
        placeholderTextColor="#666"
      />
      <TextInput
        style={styles.input}
        placeholder="Password"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
        placeholderTextColor="#666"
      />
      {error ? <Text style={styles.error}>{error}</Text> : null}
      <TouchableOpacity style={styles.loginButton} onPress={handleLogin}>
        <Text style={styles.buttonText}>Log In</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.backButton} onPress={handleBack}>
        <Text style={styles.backButtonText}>Back</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
    padding: 16,
    justifyContent: 'center',
  },
  header: {
    fontSize: 36,
    fontWeight: '800',
    color: '#1E3A8A',
    textAlign: 'center',
    letterSpacing: 1.5,
    textShadowColor: 'rgba(0, 0, 0, 0.2)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },
  subheader: {
    fontSize: 20,
    fontWeight: '600',
    color: '#3B82F6', // Lighter blue for contrast
    textAlign: 'center',
    marginTop: 8,
    textShadowColor: 'rgba(0, 0, 0, 0.1)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 1,
  },
  input: {
    backgroundColor: '#FFFFFF',
    padding: 12,
    borderRadius: 8,
    marginBottom: 16,
    fontSize: 16,
    borderColor: '#DDD',
    borderWidth: 1,
  },
  error: {
    color: '#D32F2F',
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 16,
  },
  loginButton: {
    backgroundColor: '#1E3A8A',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 16,
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  signUpText: {
    color: '#1E3A8A',
    fontSize: 14,
    textAlign: 'center',
  },
   backButton: {
    backgroundColor: '#FFFFFF',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    borderColor: '#1E3A8A',
    borderWidth: 1,
    marginBottom: 16,
  },
  backButtonText: {
    color: '#1E3A8A',
    fontSize: 16,
    fontWeight: '600',
  }
});

export default LoginScreen;