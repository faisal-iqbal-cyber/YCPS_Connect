import React, { useEffect, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  Image,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  Alert,
} from 'react-native';
import { getDatabase, onValue, ref, update } from 'firebase/database';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

function OrganizerHome({ navigation, route }) {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [commentInputs, setCommentInputs] = useState({});
  const userUID = route.params?.userUID;

  useEffect(() => {
    console.log('OrganizerHome route.params:', route.params); // Debug log
    if (!userUID) {
      setError('User not authenticated. Please log in.');
      setLoading(false);
      setTimeout(() => navigation.replace('LoginScreen'), 2000);
      return;
    }

    const db = getDatabase();
    const eventsRef = ref(db, 'events');

    const unsubscribe = onValue(
      eventsRef,
      (snapshot) => {
        const data = snapshot.val();
        if (data) {
          const eventsList = Object.entries(data).map(([id, event]) => ({
            id,
            ...event,
            likes: event.likes || [],
            comments: event.comments || [],
          }));
          console.log('Fetched events:', eventsList); // Debug log
          setEvents(eventsList);
        } else {
          setEvents([]);
        }
        setLoading(false);
      },
      (err) => {
        console.error('Error fetching events:', err);
        setError('Failed to load events. Please try again.');
        setLoading(false);
      }
    );

    return () => unsubscribe();
  }, [userUID, navigation]);

  const handleLike = async (eventId, currentLikes) => {
    if (!userUID) {
      Alert.alert('Error', 'You must be logged in to like an event.');
      return;
    }

    const db = getDatabase();
    const eventRef = ref(db, `events/${eventId}`);
    const updatedLikes = currentLikes.includes(userUID)
      ? currentLikes.filter((uid) => uid !== userUID)
      : [...currentLikes, userUID];

    try {
      await update(eventRef, { likes: updatedLikes });
    } catch (err) {
      console.error('Error updating likes:', err);
      Alert.alert('Error', 'Failed to update like. Please try again.');
    }
  };

  const handleComment = async (eventId) => {
    if (!userUID) {
      Alert.alert('Error', 'You must be logged in to comment.');
      return;
    }

    const commentText = commentInputs[eventId]?.trim();
    if (!commentText) {
      Alert.alert('Error', 'Please enter a comment.');
      return;
    }

    const db = getDatabase();
    const eventRef = ref(db, `events/${eventId}`);
    const newComment = {
      userUID,
      text: commentText,
      createdAt: new Date().toISOString(),
    };

    try {
      const currentComments = events.find((event) => event.id === eventId)?.comments || [];
      await update(eventRef, { comments: [...currentComments, newComment] });
      setCommentInputs((prev) => ({ ...prev, [eventId]: '' }));
    } catch (err) {
      console.error('Error adding comment:', err);
      Alert.alert('Error', 'Failed to add comment. Please try again.');
    }
  };

  const renderEvent = ({ item }) => (
    <View style={styles.eventCard}>
      {item.image && (
        <Image
          source={{ uri: item.image }}
          style={styles.eventImage}
          resizeMode="cover"
        />
      )}
      <View style={styles.eventDetails}>
        <Text style={styles.eventDescription}>{item.description}</Text>
        <Text style={styles.eventDate}>
          Created: {new Date(item.createdAt).toLocaleDateString()}
        </Text>
        <Text style={styles.eventOrganizers}>
          Organizers: {item.organizers.map((org) => org.name).join(', ')}
        </Text>
        <View style={styles.actionContainer}>
          <TouchableOpacity
            style={[
              styles.actionButton,
              item.likes.includes(userUID) && styles.likedButton,
            ]}
            onPress={() => handleLike(item.id, item.likes)}
            activeOpacity={0.7}
          >
            <Icon
              name={item.likes.includes(userUID) ? 'heart' : 'heart-outline'}
              size={20}
              color={item.likes.includes(userUID) ? '#FF3B30' : '#3B82F6'}
            />
            <Text style={styles.actionText}>
              {item.likes.length} {item.likes.length === 1 ? 'Like' : 'Likes'}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.actionButton}
            onPress={() => navigation.navigate('Comments', { eventId: item.id, comments: item.comments })}
            activeOpacity={0.7}
          >
            <Icon name="comment-outline" size={20} color="#3B82F6" />
            <Text style={styles.actionText}>
              {item.comments.length} {item.comments.length === 1 ? 'Comment' : 'Comments'}
            </Text>
          </TouchableOpacity>
        </View>
        <TextInput
          style={styles.commentInput}
          placeholder="Write a comment..."
          value={commentInputs[item.id] || ''}
          onChangeText={(text) => setCommentInputs((prev) => ({ ...prev, [eventId]: text }))}
          onSubmitEditing={() => handleComment(item.id)}
        />
        {item.comments.length > 0 && (
          <View style={styles.commentsContainer}>
            <Text style={styles.commentsTitle}>Recent Comments:</Text>
            {item.comments.slice(-2).map((comment, index) => (
              <Text key={index} style={styles.commentText}>
                {comment.text} <Text style={styles.commentDate}>
                  ({new Date(comment.createdAt).toLocaleDateString()})
                </Text>
              </Text>
            ))}
            {item.comments.length > 2 && (
              <TouchableOpacity
                onPress={() => navigation.navigate('Comments', { eventId: item.id, comments: item.comments })}
              >
                <Text style={styles.viewAllComments}>View all comments</Text>
              </TouchableOpacity>
            )}
          </View>
        )}
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.headerContainer}>
        <Text style={styles.header}>Organizer Home</Text>
        <Text style={styles.subheader}>All Events</Text>
      </View>

      {loading ? (
        <ActivityIndicator size="large" color="#1E3A8A" style={styles.loader} />
      ) : error ? (
        <Text style={styles.error}>{error}</Text>
      ) : events.length === 0 ? (
        <Text style={styles.noEvents}>No events found.</Text>
      ) : (
        <FlatList
          data={events}
          keyExtractor={(item) => item.id}
          renderItem={renderEvent}
          contentContainerStyle={styles.eventList}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
    padding: 16,
  },
  headerContainer: {
    marginBottom: 20,
    alignItems: 'center',
  },
  header: {
    fontSize: 28,
    fontWeight: '800',
    color: '#1E3A8A',
    textAlign: 'center',
  },
  subheader: {
    fontSize: 18,
    fontWeight: '600',
    color: '#3B82F6',
    marginTop: 8,
  },
  eventList: {
    paddingBottom: 20,
  },
  eventCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    shadowOffset: { width: 0, height: 2 },
    elevation: 3,
    overflow: 'hidden',
  },
  eventImage: {
    width: '100%',
    height: 150,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
  },
  eventDetails: {
    padding: 12,
  },
  eventDescription: {
    fontSize: 16,
    color: '#1F2937',
    marginBottom: 8,
  },
  eventDate: {
    fontSize: 14,
    color: '#6B7280',
    marginBottom: 4,
  },
  eventOrganizers: {
    fontSize: 14,
    color: '#6B7280',
    marginBottom: 8,
  },
  actionContainer: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    marginBottom: 8,
    paddingHorizontal: 8,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F0F0F0',
    borderRadius: 20,
    paddingVertical: 8,
    paddingHorizontal: 12,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 3,
    shadowOffset: { width: 0, height: 1 },
    elevation: 2,
  },
  likedButton: {
    backgroundColor: '#FFE4E1',
  },
  actionText: {
    color: '#3B82F6',
    fontSize: 14,
    fontWeight: '600',
    marginLeft: 6,
  },
  commentInput: {
    backgroundColor: '#F0F0F0',
    padding: 10,
    borderRadius: 8,
    marginBottom: 8,
    fontSize: 14,
  },
  commentsContainer: {
    marginTop: 8,
  },
  commentsTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#1F2937',
    marginBottom: 4,
  },
  commentText: {
    fontSize: 14,
    color: '#1F2937',
    marginBottom: 4,
  },
  commentDate: {
    fontSize: 12,
    color: '#6B7280',
  },
  viewAllComments: {
    color: '#3B82F6',
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
  },
  loader: {
    marginTop: 20,
  },
  error: {
    color: '#D32F2F',
    fontSize: 16,
    textAlign: 'center',
    marginTop: 20,
  },
  noEvents: {
    fontSize: 16,
    color: '#6B7280',
    textAlign: 'center',
    marginTop: 20,
  },
});

export default OrganizerHome;