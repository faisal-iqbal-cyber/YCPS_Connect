import { createDrawerNavigator } from '@react-navigation/drawer';
import Logout from './Logout';
import OrganizerHome from './OrganizerHome';
const Drawer = createDrawerNavigator();

function OrganizerDashboard({navigation,route}) {
  return (
    <Drawer.Navigator>
      <Drawer.Screen name="OrganizerHome" component={OrganizerHome} options={{ title: 'Organizer Home' }}  initialParams={{ userUID: route.params?.userUID }} />
       <Drawer.Screen name="Logout" component={Logout} options={{ title: 'Logout' }} />
    </Drawer.Navigator>
  );
}

export default OrganizerDashboard;