import { useRouter } from 'expo-router';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';

const WelcomeScreen = ({navigation}) => {
  const router = useRouter();

  const handleContinue = (role) => {
    // Navigate to appropriate screen based on role
    switch (role) {
      case 'admin':
        navigation.navigate('LoginScreen'); // Navigate to LoginScreen for Admin
        break;
      case 'student':
        navigation.navigate('StudentSignUp',{ role: 'Student' }); // Navigate to StudentHome for Student
        break;
      case 'organizer':
        navigation.navigate('OrganizerLogin'); // Navigate to OrganizerHome for Organizer
        break;
      default:
        break;
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>YCPS Connect</Text>
      <View style={styles.buttonContainer}>
        <TouchableOpacity style={styles.button} onPress={() => handleContinue('admin')}>
          <Text style={styles.buttonText}>Continue as Admin</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => handleContinue('student')}>
          <Text style={styles.buttonText}>Continue as Student</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => handleContinue('organizer')}>
          <Text style={styles.buttonText}>Continue as Organizer</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 36,
    fontWeight: 'bold',
    color: '#1E3A8A',
    marginBottom: 40,
    textAlign: 'center',
  },
  buttonContainer: {
    width: '80%',
    gap: 16,
  },
  button: {
    backgroundColor: '#3B82F6',
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 12,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    alignItems: 'center',
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '600',
  },
});

export default WelcomeScreen; // Ensure default export is present