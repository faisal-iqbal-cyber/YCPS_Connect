import { MaterialIcons } from '@expo/vector-icons';
import { Picker } from '@react-native-picker/picker';
import * as FileSystem from 'expo-file-system'; // Added import for FileSystem
import * as ImagePicker from 'expo-image-picker';
import React, { useEffect, useState } from 'react';
import { Alert, FlatList, Image, Modal, Platform, ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';

export default function UserManagement({ navigation }) {
  const [users, setUsers] = useState([]);
  const [isCreateModalVisible, setIsCreateModalVisible] = useState(false);
  const [newUser, setNewUser] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    gender: '',
    department: '',
    contact: '',
    profileImage: null,
  });

  useEffect(() => {
    async function fetchUsers() {
      try {
        const response = await fetch('https://ycps-connect-default-rtdb.firebaseio.com/users.json');
        const data = await response.json();
        const usersList = data
          ? Object.keys(data).map(key => ({
              id: key,
              ...data[key],
              profileImage: data[key].profileImage || '',
            }))
          : [];
        setUsers(usersList);
      } catch (error) {
        Alert.alert('Error', 'Failed to fetch users.');
      }
    }
    fetchUsers();

    (async () => {
      if (Platform.OS !== 'web') {
        const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
        if (status !== 'granted') {
          Alert.alert('Permission Denied', 'Sorry, we need camera roll permissions to pick an image!');
        }
      }
    })();
  }, []);

  const pickImage = async () => {
    const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permissionResult.granted) {
      Alert.alert('Permission required', 'Please allow access to your media library');
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });

    if (!result.canceled) {
      const imageUri = result.assets[0].uri;
      try {
        const imageName = `profile_${Date.now()}.jpg`;
        const imageDir = `${FileSystem.documentDirectory}profile_images/`;

        await FileSystem.makeDirectoryAsync(imageDir, { intermediates: true });
        const newPath = `${imageDir}${imageName}`;
        await FileSystem.moveAsync({
          from: imageUri,
          to: newPath,
        });

        setNewUser({ ...newUser, profileImage: newPath }); // Update newUser.profileImage
      } catch (error) {
        console.error('Error saving image:', error);
        Alert.alert('Error', 'Failed to save image');
      }
    }
  };

  // Mock uploadImage function (replace with actual Firebase Storage upload logic)
  const uploadImage = async (uri, userId) => {
    try {
      // Example: Upload to Firebase Storage (requires firebase/storage import)
      // This is a placeholder; implement actual Firebase Storage upload logic
      return uri; // For now, return the local URI
    } catch (error) {
      console.error('Error uploading image:', error);
      throw new Error('Failed to upload image');
    }
  };

  const handleCreateOrganizer = async () => {
    try {
      if (!newUser.name || !newUser.email || !newUser.password || !newUser.confirmPassword || !newUser.gender || !newUser.department || !newUser.contact) {
        throw new Error('All fields are required.');
      }

      if (newUser.password !== newUser.confirmPassword) {
        throw new Error('Passwords do not match.');
      }

      if (newUser.password.length !== 8) {
        throw new Error('Password must be exactly 8 characters long.');
      }

      if (newUser.contact.length !== 11) {
        throw new Error('Contact number must be exactly 11 digits.');
      }

      const response = await fetch('https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=AIzaSyB9GwYufV1zIxpuBQ2A_coiOlbjxyWgCc0', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: newUser.email,
          password: newUser.password,
          returnSecureToken: true,
        }),
      });
      const result = await response.json();
      if (result.error) throw new Error(result.error.message);

      let profileImageUrl = '';
      if (newUser.profileImage) {
        profileImageUrl = await uploadImage(newUser.profileImage, result.localId);
      }

      const userData = {
        name: newUser.name,
        email: newUser.email,
        role: 'Organizer',
        gender: newUser.gender,
        department: newUser.department,
        contact: newUser.contact,
        profileImage: profileImageUrl,
        createdAt: new Date().toISOString(),
      };
      await fetch(`https://ycps-connect-default-rtdb.firebaseio.com/users/${result.localId}.json`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(userData),
      });

      Alert.alert('Success', 'Organizer account created!');
      setIsCreateModalVisible(false);
      setNewUser({
        name: '',
        email: '',
        password: '',
        confirmPassword: '',
        gender: '',
        department: '',
        contact: '',
        profileImage: null,
      });
      // Refresh user list
      const fetchUsers = async () => {
        const response = await fetch('https://ycps-connect-default-rtdb.firebaseio.com/users.json');
        const data = await response.json();
        const usersList = data
          ? Object.keys(data).map(key => ({
              id: key,
              ...data[key],
              profileImage: data[key].profileImage || '',
            }))
          : [];
        setUsers(usersList);
      };
      await fetchUsers();
    } catch (error) {
      Alert.alert('Error', error.message);
    }
  };

  const handleDeleteUser = async (userId) => {
    try {
      // Note: Deleting a user from Firebase Authentication requires an ID token
      // This is a placeholder; implement proper authentication token retrieval
      await fetch(`https://ycps-connect-default-rtdb.firebaseio.com/users/${userId}.json`, { method: 'DELETE' });
      setUsers(users.filter(user => user.id !== userId));
      Alert.alert('Success', 'User deleted!');
    } catch (error) {
      Alert.alert('Error', 'Failed to delete user. Check admin permissions.');
    }
  };

  const renderUser = ({ item }) => (
    <View style={styles.userCard}>
      <View style={styles.userInfo}>
        {item.profileImage ? (
          <Image source={{ uri: item.profileImage }} style={styles.userImage} />
        ) : (
          <View style={styles.userImagePlaceholder} />
        )}
        <View style={styles.userText}>
          <Text style={styles.userName}>{item.name}</Text>
          <Text style={styles.userDetail}>{item.department || 'N/A'}</Text>
          <Text style={styles.userDetail}>{item.email || 'N/A'}</Text>
          <Text style={styles.userDetail}>{item.contact || 'N/A'}</Text>
          <Text style={styles.userRole}>Role: {item.role || 'Organizer'}</Text>
        </View>
      </View>
      <TouchableOpacity style={styles.deleteButton} onPress={() => handleDeleteUser(item.id)}>
        <MaterialIcons name="delete" size={20} color="#fff" />
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>User Management</Text>
        <TouchableOpacity style={styles.addButton} onPress={() => setIsCreateModalVisible(true)}>
          <MaterialIcons name="add" size={20} color="#fff" />
          <Text style={styles.addText}>Add Organizer</Text>
        </TouchableOpacity>
      </View>
      <FlatList
        data={users}
        renderItem={renderUser}
        keyExtractor={(item) => item.id}
        ListEmptyComponent={<Text style={styles.emptyText}>No users found.</Text>}
        showsVerticalScrollIndicator={false}
      />
      <Modal
        visible={isCreateModalVisible}
        animationType="slide"
        onRequestClose={() => setIsCreateModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <ScrollView contentContainerStyle={styles.scrollContainer}>
            <Text style={styles.modalTitle}>Create Organizer Account</Text>
            <TextInput
              style={styles.input}
              placeholder="Name"
              value={newUser.name}
              onChangeText={(text) => setNewUser({ ...newUser, name: text })}
            />
            <TextInput
              style={styles.input}
              placeholder="Email"
              value={newUser.email}
              onChangeText={(text) => setNewUser({ ...newUser, email: text })}
              keyboardType="email-address"
              autoCapitalize="none"
            />
            <Picker
              selectedValue={newUser.gender}
              onValueChange={(value) => setNewUser({ ...newUser, gender: value })}
              style={styles.picker}
            >
              <Picker.Item label="Select Gender" value="" />
              <Picker.Item label="Male" value="Male" />
              <Picker.Item label="Female" value="Female" />
              <Picker.Item label="Other" value="Other" />
            </Picker>
            <TextInput
              style={styles.input}
              placeholder="Department"
              value={newUser.department}
              onChangeText={(text) => setNewUser({ ...newUser, department: text })}
            />
            <TextInput
              style={styles.input}
              placeholder="Contact"
              value={newUser.contact}
              onChangeText={(text) => setNewUser({ ...newUser, contact: text })}
              keyboardType="numeric"
              maxLength={11}
            />
            <TextInput
              style={styles.input}
              placeholder="Password"
              value={newUser.password}
              onChangeText={(text) => setNewUser({ ...newUser, password: text })}
              secureTextEntry
              maxLength={8}
            />
            <TextInput
              style={styles.input}
              placeholder="Confirm Password"
              value={newUser.confirmPassword}
              onChangeText={(text) => setNewUser({ ...newUser, confirmPassword: text })}
              secureTextEntry
              maxLength={8}
            />
            <TouchableOpacity style={styles.uploadContainer} onPress={pickImage}>
              <Text style={styles.uploadText}>Upload Image</Text>
              <View style={styles.uploadButton}>
                <Text style={styles.uploadButtonText}>UPLOAD IMAGE</Text>
                <MaterialIcons name="add-photo-alternate" size={18} color="#fff" style={{ marginLeft: 5 }} />
              </View>
            </TouchableOpacity>
            {newUser.profileImage && (
              <Image
                source={{ uri: newUser.profileImage }}
                style={{ width: 100, height: 100, alignSelf: 'center', marginTop: 10, borderRadius: 10 }}
              />
            )}
            <TouchableOpacity style={styles.saveButton} onPress={handleCreateOrganizer}>
              <Text style={styles.saveText}>Create</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.cancelButton} onPress={() => setIsCreateModalVisible(false)}>
              <Text style={styles.cancelText}>Cancel</Text>
            </TouchableOpacity>
          </ScrollView>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  title: { fontSize: 20, fontWeight: '700', color: '#1E3A8A' },
  addButton: { backgroundColor: '#4CAF50', padding: 10, borderRadius: 8, flexDirection: 'row', alignItems: 'center' },
  addText: { color: '#fff', fontSize: 16, marginLeft: 5 },
  userCard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#fff',
    padding: 20,
    marginBottom: 15,
    borderRadius: 8,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    minHeight: 100,
  },
  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  userImage: { width: 60, height: 60, borderRadius: 30, marginRight: 15 },
  userImagePlaceholder: { width: 60, height: 60, borderRadius: 30, backgroundColor: '#E5E7EB', marginRight: 15 },
  userText: { flex: 1 },
  userName: { fontSize: 16, fontWeight: '600', color: '#1F2937', marginBottom: 4 },
  userDetail: { fontSize: 14, color: '#6B7280', marginBottom: 2 },
  userRole: { fontSize: 12, color: '#374151', marginBottom: 2 },
  deleteButton: {
    backgroundColor: '#FF4444',
    padding: 12,
    borderRadius: 4,
    marginLeft: 10,
  },
  emptyText: { textAlign: 'center', color: '#6B7280', fontSize: 14 },
  modalContainer: { flex: 1, backgroundColor: '#fff' },
  scrollContainer: { padding: 20, paddingBottom: 40 },
  modalTitle: { fontSize: 20, fontWeight: '700', color: '#1E3A8A', textAlign: 'center', marginBottom: 20 },
  input: { borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 8, padding: 10, marginBottom: 15, fontSize: 16 },
  picker: {
    borderWidth: 1,
    borderColor: '#E5E7EB',
    borderRadius: 8,
    marginBottom: 15,
    fontSize: 16,
    backgroundColor: '#fff',
  },
  uploadContainer: { marginBottom: 15 },
  uploadText: { fontSize: 16, color: '#1F2937', marginBottom: 5 },
  uploadButton: { backgroundColor: '#2196F3', padding: 10, borderRadius: 8, flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
  uploadButtonText: { color: '#fff', fontSize: 16 },
  saveButton: { backgroundColor: '#4CAF50', padding: 12, borderRadius: 8, alignItems: 'center' },
  saveText: { color: '#fff', fontSize: 16, fontWeight: '600' },
  cancelButton: { backgroundColor: '#FF4444', padding: 12, borderRadius: 8, alignItems: 'center', marginTop: 10 },
  cancelText: { color: '#fff', fontSize: 16, fontWeight: '600' },
});