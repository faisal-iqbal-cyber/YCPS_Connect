import { useFocusEffect, useNavigation } from '@react-navigation/native';
import * as ImagePicker from 'expo-image-picker';
import { getDatabase, push, ref } from 'firebase/database';
import React, { useState } from 'react';
import {
  Image,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View
} from 'react-native';

export default function CreateEvent() {
  const navigation = useNavigation();
  const [description, setDescription] = useState('');
  const [image, setImage] = useState(null);
  const [selectedOrganizers, setSelectedOrganizers] = useState([]);

  useFocusEffect(
    React.useCallback(() => {
      if (navigation.getState()?.routes) {
        const route = navigation.getState().routes.find(r => r.name === 'CreateEvent');
        const params = route?.params;
        if (params) {
          // Restore description, image, and selectedOrganizers from navigation params
          if (params.description) setDescription(params.description);
          if (params.image) setImage(params.image);
          if (params.selectedOrganizers) setSelectedOrganizers(params.selectedOrganizers);
        }
      }
    }, [navigation])
  );

  const pickImage = async () => {
    const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permissionResult.granted) {
      alert('Permission to access camera roll is required!');
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });

    if (!result.canceled) {
      setImage(result.assets[0].uri);
    }
  };

  const handleCreateEvent = () => {
    if (!description || !image || selectedOrganizers.length === 0) {
      alert('Please complete all fields.');
      return;
    }

    const db = getDatabase();
    const eventsRef = ref(db, 'events');
    const newEvent = {
      description,
      image,
      organizers: selectedOrganizers,
      createdAt: new Date().toISOString(),
    };
    push(eventsRef, newEvent)
      .then(() => {
        alert('Event created successfully!');
        setDescription('');
        setImage(null);
        setSelectedOrganizers([]);
        navigation.navigate('AdminDashboard'); 
      })
      .catch((error) => {
        alert('Failed to create event.');
        console.error(error);
      });
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Create Event</Text>

      <TextInput
        style={styles.input}
        placeholder="Event Description"
        multiline
        value={description}
        onChangeText={setDescription}
      />

      <TouchableOpacity style={styles.imagePicker} onPress={pickImage}>
        {image ? (
          <Image source={{ uri: image }} style={styles.image} />
        ) : (
          <Text style={styles.imageText}>Pick Event Image</Text>
        )}
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.assignBtn}
        onPress={() => navigation.navigate('AssignOrganizers', { 
          selectedOrganizers,
          description, // Pass current description
          image // Pass current image
        })}
      >
        <Text style={styles.assignText}>Assign Organizers</Text>
      </TouchableOpacity>

      {selectedOrganizers.length > 0 && (
        <View style={styles.selectedBox}>
          <Text style={styles.selectedTitle}>Selected Organizers:</Text>
          {selectedOrganizers.map((org, idx) => (
            <Text key={idx} style={styles.selectedItem}>{org.name} ({org.email})</Text>
          ))}
        </View>
      )}

      <TouchableOpacity style={styles.createBtn} onPress={handleCreateEvent}>
        <Text style={styles.createText}>Create Event</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    borderColor: '#ccc',
    borderWidth: 1,
    padding: 10,
    borderRadius: 8,
    height: 100,
    textAlignVertical: 'top',
    marginBottom: 20,
  },
  imagePicker: {
    height: 200,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  image: {
    width: '100%',
    height: '100%',
    borderRadius: 8,
  },
  imageText: {
    color: '#888',
  },
  assignBtn: {
    backgroundColor: '#007AFF',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 10,
  },
  assignText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  selectedBox: {
    backgroundColor: '#f0f0f0',
    padding: 10,
    borderRadius: 8,
    marginBottom: 20,
  },
  selectedTitle: {
    fontWeight: 'bold',
    marginBottom: 5,
  },
  selectedItem: {
    fontSize: 14,
  },
  createBtn: {
    backgroundColor: '#28a745',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
  },
  createText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
});