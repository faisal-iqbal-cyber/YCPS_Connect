import React, { useEffect } from 'react';
import { View, Text, StyleSheet, Animated } from 'react-native';

// SplashScreen component
const SplashScreen = ({ navigation }) => {
  // Animation state
  const fadeAnim = new Animated.Value(0); // Initial opacity: 0

  // Run fade-in animation on component mount
  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1, // Fade to full opacity
      duration: 2000, // 2 seconds
      useNativeDriver: true,
    }).start(() => {
      // Navigate to Home screen after 3 seconds
      setTimeout(() => {
        navigation.replace('WelcomeScreen'); 
      }, 1000);
    });
  }, [fadeAnim, navigation]);

  return (
    <View style={styles.container}>
      <Animated.View style={[styles.logoContainer, { opacity: fadeAnim }]}>
        <Text style={styles.logoText}>YCPS Connect</Text>
        <Text style={styles.tagline}>Your Community, Your Events</Text>
      </Animated.View>
    </View>
  );
};

// Styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1E3A8A', // Deep blue background
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoContainer: {
    alignItems: 'center',
  },
  logoText: {
    fontSize: 48,
    fontWeight: 'bold',
    color: '#FFFFFF', // White text
  },
  tagline: {
    fontSize: 18,
    color: '#FFFFFF',
    marginTop: 10,
    opacity: 0.8,
  },
});

export default SplashScreen;