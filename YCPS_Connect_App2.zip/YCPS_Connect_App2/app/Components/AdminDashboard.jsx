import { createDrawerNavigator } from '@react-navigation/drawer';
import { MaterialIcons } from '@expo/vector-icons';
import AdminHome from './AdminHome';
import UserManagment from './UserManagment';
import CreateEvent from './CreateEvent';
import SendNotification from './SendNotification'
const Drawer = createDrawerNavigator();
import Logout from './Logout'

function AdminDashboard() {
  return (
    <Drawer.Navigator>
      <Drawer.Screen name="AdminHome" component={AdminHome} options={{ title: 'Admin' }} />
      <Drawer.Screen name="UserManagment" component={UserManagment} options={{ title: 'User Management',drawerIcon: ({ color, size }) => (<MaterialIcons name="people" size={size} color={color} />)}}/>
      <Drawer.Screen name="CreateEvent" component={CreateEvent} options={{ title: 'Create Event',drawerIcon: ({ color, size }) => (<MaterialIcons name="event" size={size} color={color} />)}} />
      <Drawer.Screen name="SendNotification" component={SendNotification} options={{ title: 'Send Notification',drawerIcon: ({ color, size }) => (
      <MaterialIcons name="notifications" size={size} color={color} />)}} />
       <Drawer.Screen name="Logout" component={Logout} options={{ title: 'Logout' }} />
    </Drawer.Navigator>
  );
}

export default AdminDashboard;