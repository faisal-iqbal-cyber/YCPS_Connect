import React from 'react'
import{Text,View} from 'react-native' 
function SendNotification() {
  return (
    <View>
        <Text>This is Send Notification Page </Text>
    </View>
  )
}

export default SendNotification
