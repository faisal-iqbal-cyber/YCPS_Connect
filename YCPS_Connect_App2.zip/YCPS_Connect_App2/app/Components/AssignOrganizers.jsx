import Checkbox from 'expo-checkbox';
import { getDatabase, ref, update } from 'firebase/database';
import { useEffect, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  Alert,
} from 'react-native';
import { db } from '../../config/firebaseConfig';

const AssignOrganizers = ({ navigation, route }) => {
  const [organizers, setOrganizers] = useState([]);
  const [selected, setSelected] = useState({});
  const [loading, setLoading] = useState(true);

  // Initialize selected organizers from route params
  useEffect(() => {
    if (route.params?.selectedOrganizers) {
      const initialSelected = {};
      route.params.selectedOrganizers.forEach(org => {
        initialSelected[org.id] = true;
      });
      setSelected(initialSelected);
    }
    fetchOrganizers();
  }, [route.params?.selectedOrganizers]);

  const fetchOrganizers = async () => {
    try {
      setLoading(true);
      const response = await fetch(
        'https://ycps-connect-default-rtdb.firebaseio.com/users.json'
      );
      const data = await response.json();
      const organizerList = Object.entries(data || {})
        .filter(([id, user]) => user.role === 'Organizer')
        .map(([id, user]) => ({ id, ...user }));
      setOrganizers(organizerList);
    } catch (error) {
      console.error('Error fetching organizers:', error);
    } finally {
      setLoading(false);
    }
  };

  const toggleSelect = (id) => {
    setSelected((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const handleDone = async () => {
    const selectedOrganizers = organizers.filter((org) => selected[org.id]);
    if (selectedOrganizers.length === 0) {
      Alert.alert('Warning', 'Please select at least one organizer.');
      return;
    }

    const db = getDatabase();
    const eventDescription = route.params?.description || 'New Event';
    const eventImage = route.params?.image || 'https://via.placeholder.com/150';

    // Send notification to each selected organizer
    const notifications = {};
    selectedOrganizers.forEach((organizer) => {
      const notificationId = `${organizer.id}_${Date.now()}`;
      notifications[`notifications/${organizer.id}/${notificationId}`] = {
        id: notificationId,
        message: `The admin has organized you for the event: "${eventDescription}"`,
        eventDescription: eventDescription,
        eventImage: eventImage,
        createdAt: new Date().toISOString(),
        read: false,
      };
    });

    try {
      await update(ref(db), notifications);
      console.log('Notifications sent to selected organizers:', selectedOrganizers.map(org => org.id));
    } catch (error) {
      console.error('Error sending notifications:', error);
      Alert.alert('Error', 'Failed to send notifications. Please try again.');
    }

    navigation.navigate('CreateEvent', { 
      selectedOrganizers,
      description: route.params?.description,
      image: route.params?.image
    });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Assign Organizers</Text>
      {loading ? (
        <ActivityIndicator size="large" color="blue" />
      ) : (
        <FlatList
          data={organizers}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <View style={styles.card}>
              <Image
                source={{ uri: item.profileImage || 'https://via.placeholder.com/50' }}
                style={styles.avatar}
              />
              <View style={styles.details}>
                <Text style={styles.name}>{item.name}</Text>
                <Text style={styles.text}>Dept: {item.department}</Text>
                <Text style={styles.text}>Email: {item.email}</Text>
                <Text style={styles.text}>Role: {item.role}</Text>
              </View>
              <Checkbox
                value={!!selected[item.id]}
                onValueChange={() => toggleSelect(item.id)}
                style={styles.checkbox}
              />
            </View>
          )}
        />
      )}
      <TouchableOpacity style={styles.doneButton} onPress={handleDone}>
        <Text style={styles.doneText}>Done</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 16,
    textAlign: 'center',
  },
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f2f2f2',
    padding: 10,
    marginVertical: 6,
    borderRadius: 10,
  },
  avatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 10,
  },
  details: {
    flex: 1,
  },
  name: {
    fontWeight: 'bold',
    fontSize: 16,
  },
  text: {
    fontSize: 14,
  },
  checkbox: {
    width: 24,
    height: 24,
  },
  doneButton: {
    backgroundColor: 'blue',
    padding: 12,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 10,
  },
  doneText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
});

export default AssignOrganizers;