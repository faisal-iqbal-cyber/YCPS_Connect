import { createNativeStackNavigator } from '@react-navigation/native-stack';
import AdminDashboard from './Components/AdminDashboard';
import AdminHome from './Components/AdminHome';
import AssignOrganizers from './Components/AssignOrganizers';
import Comments from './Components/Comments';
import CreateEvent from './Components/CreateEvent';
import LoginScreen from './Components/LoginScreen';
import OrganizerDashboard from './Components/OrganizerDashboard';
import OrganizerHome from './Components/OrganizerHome'; // Add this if it exists
import OrganizerLogin from './Components/OrganizerLogin';
import SplashScreen from './Components/SplashScreen';
import StudentDashboard from './Components/StudentDashboard';
import StudentHome from './Components/StudentHome'; // Add this if it exists
import StudentLoginScreen from './Components/StudentLoginScreen';
import StudentSignUp from './Components/StudentSignUp';
import WelcomeScreen from './Components/WelcomeScreen';

export default function Index() {
  const Stack = createNativeStackNavigator();
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="SplashScreen" component={SplashScreen} />
      <Stack.Screen name="LoginScreen" component={LoginScreen} />
      <Stack.Screen name="AdminHome" component={AdminHome} />
      <Stack.Screen name="StudentHome" component={StudentHome} />
      <Stack.Screen name="OrganizerHome" component={OrganizerHome} />
      <Stack.Screen name="AdminDashboard" component={AdminDashboard} />
      <Stack.Screen name="WelcomeScreen" component={WelcomeScreen} />
      <Stack.Screen name="StudentSignUp" component={StudentSignUp} />
      <Stack.Screen name="StudentLoginScreen" component={StudentLoginScreen} />
      <Stack.Screen name="StudentDashboard" component={StudentDashboard} />
      <Stack.Screen name="AssignOrganizers" component={AssignOrganizers} />
       <Stack.Screen name="CreateEvent" component={CreateEvent} />
       <Stack.Screen name="OrganizerLogin" component={OrganizerLogin} />
       <Stack.Screen name="OrganizerDashboard" component={OrganizerDashboard} />
       <Stack.Screen name="Comments" component={Comments} />
    </Stack.Navigator>
  );
}